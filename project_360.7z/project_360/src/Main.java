import control.Control;
import view.login.Login;

public class Main {
    public static void main(String[] args) {
        Control control = new Control();
        new Login();
    }
}