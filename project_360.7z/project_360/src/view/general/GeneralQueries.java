package view.general;

public class GeneralQueries {
}
