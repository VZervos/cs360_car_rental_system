package view.utils;

import javax.swing.*;
import java.util.List;

public abstract class ParametersPanel extends JPanel {
    public abstract List<String> getParameters();
}
