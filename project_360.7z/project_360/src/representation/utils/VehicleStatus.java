package representation.utils;

public enum VehicleStatus {READY, RENTED, REPAIR, MAINTENANCE}
